### تقویم هجری‌شمسی و اوقات شرعی برای میزکار گنوم لینوکس
### Persian calendar and prayer tiems for *Gnome-Shell*
---
+ قابلیت نمایش همزمان سه تاریخ هجری‌شمسی، هجری‌قمری و میلادی
+ محاسبه و نمایش اوقات شرعی و پخش اذان با تنظیمات پیشرفته
+ نمایش تعطیلی‌ها و مناسبت‌های رسمی تقویم ج.ا. ایران
---

![Screenshot](https://github.com/SCR-IR/gnome-shamsi-calendar/blob/main/Screenshot.gif?raw=true)

#### Install , نصب:
* https://github.com/SCR-IR/gnome-shamsi-calendar/releases

#### Check last version , بررسی آخرین نسخه:
* https://jdf.scr.ir/gnome_shamsi_calendar

#### Other links , سایر پیوندها:
* https://extensions.gnome.org/extension/3618/
* https://github.com/scr-ir/gnome-shamsi-calendar
